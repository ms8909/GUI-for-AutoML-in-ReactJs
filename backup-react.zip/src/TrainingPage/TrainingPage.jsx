import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import './index.css';
import {projectActions, userActions} from '../_actions';
import Steps, { Step } from 'rc-steps';
import CircularProgressbar from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import {Line} from 'react-chartjs-2';
import {HorizontalBar} from 'react-chartjs-2';
import {TreeViewer} from "../_components";


class TrainingPage extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            submitted: false,
            active: 0,
            tab: 0
        }
        this.metricChange = this.metricChange.bind(this);
        this.modelClick = this.modelClick.bind(this);
    }

    componentDidMount() {
        const { id } = this.props.match.params;
        this.setState({
            project_id: id,
        });
        this.props.dispatch(projectActions.getProject(id));
        this.props.dispatch(projectActions.geTrainingDetail(id));
        this.props.dispatch(projectActions.geTrainingMetric())
    }

    metricChange(event){
        let metric_id = event.target.value;
        this.props.dispatch(projectActions.geTrainingModels(this.state.project_id, metric_id))
    }

    modelClick(e, id){
        this.setState({'active': id})
        let { dispatch } = this.props;
        dispatch(projectActions.getAccuracy(id, this.state.project_id));
        dispatch(projectActions.getROC(id, this.state.project_id));
        dispatch(projectActions.getBluePrint(id, this.state.project_id));
        dispatch(projectActions.getLossInteraction(id, this.state.project_id));
        dispatch(projectActions.getFeatureImportance(id, this.state.project_id));
        dispatch(projectActions.getActualPrediction(id, this.state.project_id));
    }

    render() {
        const { groups  } = this.props;
        const { authentication } = this.props;
        const { submitted  } = this.state;
        const percentage = 66;
        const models = [{id: 0, name: "Simple Neural Network"},
            {id: 1, name: "XGBoost Extreme"},
            {id: 2, name: "Logistic Regression"},
            {id: 3, name: "Nasic Linear Regression"},
        ];


        const list = models && models.map((obj) =>
          <li className={this.state.active == obj.id ? 'active': ''} key={obj.id} onClick={(e) => this.modelClick(e, obj.id)}>{obj.name}</li>
        );

        const roc_data = {
            labels: ['0.1', '0.2', '0.3', '0.4', '0.5', '0.6', '0.7'],
            datasets: [
                {
                    label: 'Roc',
                    fill: false,
                    lineTension: 0.1,
                    backgroundColor: 'rgba(75,192,192,0.4)',
                    borderColor: 'rgba(75,192,192,1)',
                    borderCapStyle: 'butt',
                    borderDash: [],
                    borderDashOffset: 0.0,
                    borderJoinStyle: 'miter',
                    pointBorderColor: 'rgba(75,192,192,1)',
                    pointBackgroundColor: '#fff',
                    pointBorderWidth: 1,
                    pointHoverRadius: 5,
                    pointHoverBackgroundColor: 'rgba(75,192,192,1)',
                    pointHoverBorderColor: 'rgba(220,220,220,1)',
                    pointHoverBorderWidth: 2,
                    pointRadius: 1,
                    pointHitRadius: 0.01,
                    data: [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7]
                }
            ]
        };

        const features_data = {
            labels: ['Style', 'Segment', 'Store', 'Size', 'Availability'],
            datasets: [
                {
                    label: 'Feature Importance',
                    backgroundColor: 'rgba(255,99,132,0.2)',
                    borderColor: 'rgba(255,99,132,1)',
                    borderWidth: 1,
                    hoverBackgroundColor: 'rgba(255,99,132,0.4)',
                    hoverBorderColor: 'rgba(255,99,132,1)',
                    data: [65, 59, 80, 81, 56]
                }
            ]
        };

        const loss_data = {
            labels: ['0.1', '0.2', '0.3', '0.4', '0.5', '0.6', '0.7'],
            datasets: [
                {
                    label: 'Loss vs Iteration',
                    fill: false,
                    lineTension: 0.1,
                    backgroundColor: 'rgba(75,192,192,0.4)',
                    borderColor: 'rgba(75,192,192,1)',
                    borderCapStyle: 'butt',
                    borderDash: [],
                    borderDashOffset: 0.0,
                    borderJoinStyle: 'miter',
                    pointBorderColor: 'rgba(75,192,192,1)',
                    pointBackgroundColor: '#fff',
                    pointBorderWidth: 1,
                    pointHoverRadius: 5,
                    pointHoverBackgroundColor: 'rgba(75,192,192,1)',
                    pointHoverBorderColor: 'rgba(220,220,220,1)',
                    pointHoverBorderWidth: 2,
                    pointRadius: 1,
                    pointHitRadius: 0.01,
                    data: [0.5, 0.2, 0.3, 0.3, 0.5, 0.6, 0.3]
                }
            ]
        };

        const prediction_data = {
            labels: ['0.1', '0.2', '0.3', '0.4', '0.5', '0.6', '0.7'],
            datasets: [
                {
                    label: 'Actual',
                    fill: false,
                    lineTension: 0.1,
                    backgroundColor: 'rgba(255,99,132,0.2)',
                    borderColor: 'rgba(255,99,132,1)',
                    borderCapStyle: 'butt',
                    borderDash: [],
                    borderDashOffset: 0.0,
                    borderJoinStyle: 'miter',
                    pointBorderColor: 'rgba(75,192,192,1)',
                    pointBackgroundColor: '#fff',
                    pointBorderWidth: 1,
                    pointHoverRadius: 5,
                    pointHoverBackgroundColor: 'rgba(75,192,192,1)',
                    pointHoverBorderColor: 'rgba(220,220,220,1)',
                    pointHoverBorderWidth: 2,
                    pointRadius: 1,
                    pointHitRadius: 0.01,
                    data: [0.1, 0.5, 0.3, 0.3, 0.1, 0.6, 0.3]
                },
                {
                    label: 'Prediction',
                    fill: false,
                    lineTension: 0.1,
                    backgroundColor: 'rgba(75,192,192,0.4)',
                    borderColor: 'rgba(75,192,192,1)',
                    borderCapStyle: 'butt',
                    borderDash: [],
                    borderDashOffset: 0.0,
                    borderJoinStyle: 'miter',
                    pointBorderColor: 'rgba(75,192,192,1)',
                    pointBackgroundColor: '#fff',
                    pointBorderWidth: 1,
                    pointHoverRadius: 5,
                    pointHoverBackgroundColor: 'rgba(75,192,192,1)',
                    pointHoverBorderColor: 'rgba(220,220,220,1)',
                    pointHoverBorderWidth: 2,
                    pointRadius: 1,
                    pointHitRadius: 0.01,
                    data: [0.5, 0.2, 0.3, 0.3, 0.5, 0.6, 0.3]
                }
            ]
        };


        const tree_data = [{key: 'Step1', name: 'Step1'}, {key: 'Step2', name: 'Step2', parent: 'Step1'}, {key: 'Step3', name: 'Step3', parent: 'Step1'}]


        return (
            <React.Fragment>
                <div className="row">
                    <div className="col sm-8 col-md-9">
                        <div className="card-container h-50" style={{padding: '20px'}}>
                            <div className="row">
                                <div className="col-md-5 data-container">
                                    <div className="data-inner-container">
                                        <h4>Name</h4>
                                        <p>{groups.training_detail && groups.training_detail.length > 0 && groups.training_detail[0].processed_file_d.name}</p>
                                    </div>
                                    <div className="data-inner-container">
                                        <h4>Target column</h4>
                                        <p>{groups.training_detail && groups.training_detail.length > 0 && groups.training_detail[0].y_yariable_d.column_name}</p>
                                    </div>
                                    <div className="data-inner-container">
                                        <h4>Time Variable</h4>
                                        <p>{groups.training_detail && groups.training_detail.length > 0 && groups.training_detail[0].time_yariable_d.column_name}</p>
                                    </div>
                                    <div className="data-inner-container">
                                        <h4>Problem Type</h4>
                                        <p>{groups.training_detail && groups.training_detail.length > 0 && groups.training_detail[0].problem_type_d.name}</p>
                                    </div>
                                    <div className="data-inner-container">
                                        <h4>Rows</h4>
                                        <p>{groups.training_detail && groups.training_detail.length > 0 && groups.training_detail[0].processed_file_d.rows}</p>
                                    </div>
                                    <div className="data-inner-container">
                                        <h4>Column</h4>
                                        <p>0</p>
                                    </div>
                                </div>
                                <div className="col-md-7">
                                    <div className="progress-container">
                                        <div className="time-container">
                                            <h4>Elapsed time</h4>
                                            <p>00:01:00</p>
                                        </div>
                                        <div className="progress-bar-container">
                                            <CircularProgressbar
                                                initialAnimation='true'
                                                percentage={percentage}
                                                text={`${percentage}%`}
                                            />
                                        </div>
                                        <div className="time-container">
                                            <h4>Remaining time</h4>
                                            <p>00:20:00</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col sm-4 col-md-3">
                        <div className="card-container" style={{'padding': '15px'}}>
                            <Steps direction="vertical">
                                <Step title="Loading data" />
                                <Step title="Transforming data" />
                                <Step title="Training multiple models" />
                                <Step title="Tuning parameters" />
                                <Step title="Finalizing best models" />
                                <Step title="Ready for deployment" />
                            </Steps>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col sm-8 col-md-9">
                        <div className="card-container">
                        <div className="data-inner-container">
                            <h4>Model Name</h4>
                            <p>
                                {
                                    models && models.map((obj) =>
                                        this.state.active === obj.id && obj.name
                                    )
                                }
                            </p>
                        </div>

                        <div className="card">
                            <ul className="nav nav-tabs" role="tablist">
                                <li className="active"><a onClick={(e) => this.setState({'tab': 1})} data-target="#accuracy" role="tab" data-toggle="tab">Accuracy</a></li>
                                <li ><a onClick={(e) => this.setState({'tab': 2})}data-target="#roc" role="tab" data-toggle="tab">Roc</a></li>
                                <li ><a onClick={(e) => this.setState({'tab': 3})} data-target="#blue" role="tab" data-toggle="tab">Blue print</a></li>
                                <li ><a onClick={(e) => this.setState({'tab': 4})} data-target="#feature" role="tab" data-toggle="tab">Feature Importance</a></li>
                                <li ><a onClick={(e) => this.setState({'tab': 5})} data-target="#loss" role="tab" data-toggle="tab">Loss vs iterations</a></li>
                                <li ><a onClick={(e) => this.setState({'tab': 6})} data-target="#actual" role="tab" data-toggle="tab">Actual vs prediction</a></li>

                            </ul>
                            <div className="tab-content">
                                <div role="tabpanel" className="tab-pane active" id="accuracy">
                                    <div className="data-inner-container">
                                        <h4>Metrics</h4>
                                    </div>
                                    <table border="0" width="75%">
                                        <tr>
                                            <td>Mean Absolute Error</td>
                                            <td>98.33</td>
                                        </tr>
                                        <tr>
                                            <td>Root Mean Squared Error</td>
                                            <td>33.45</td>
                                        </tr>
                                        <tr>
                                            <td>R-squared</td>
                                            <td>0.987</td>
                                        </tr>
                                        <tr>
                                            <td>Log-loss accuracy</td>
                                            <td>0.045</td>
                                        </tr>
                                    </table>
                                </div>

                                <div role="tabpanel" className="tab-pane" id="roc">
                                    <Line data={roc_data} />
                                </div>
                                <div role="tabpanel" className="tab-pane h-40" id="blue">
                                    {this.state.tab == 3 && <TreeViewer treeData={tree_data}/>}
                                </div>
                                <div role="tabpanel" className="tab-pane" id="feature">
                                    <HorizontalBar data={features_data} />
                                </div>
                                <div role="tabpanel" className="tab-pane" id="loss">
                                    <Line data={loss_data} />
                                </div>
                                <div role="tabpanel" className="tab-pane" id="actual">
                                    <Line data={prediction_data} />
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                    <div className="col sm-4 col-md-3">
                        <div className="card-container">
                            <div>
                                <div><span>Models:</span> 0/4</div>
                                <div>
                                    Rank by:
                                    <select className="form-control" onChange={this.metricChange}>
                                        {
                                            groups.metric && groups.metric.map(
                                                (obj) =>
                                                    <option key={obj.id} value={obj.id}>{obj.name}</option>
                                            )
                                        }
                                    </select>
                                </div>
                                <ul className="list-container">
                                    {list}
                                </ul>

                            </div>
                        </div>
                    </div>
                </div>
            </React.Fragment>

        );
    }
}

function mapStateToProps(state) {
    const { groups } = state;
    const { authentication } = state;
    return {
        groups,
        authentication
    };
}

const connectedTrainingPage = connect(mapStateToProps)(TrainingPage);
export { connectedTrainingPage as TrainingPage };