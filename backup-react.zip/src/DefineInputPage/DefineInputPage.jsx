import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';

import {projectActions, userActions} from '../_actions';

import DateTimePicker from 'react-datetime-picker';
import {ErrorMessage, Field, Form, Formik} from "formik";
import * as Yup from "yup";


class DefineInputPage extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            submitted: false,
        };
    }


    componentDidMount() {
        const { id } = this.props.match.params;
        this.setState({
            project_id: id,
        });
        this.props.dispatch(projectActions.getProject(id));
        this.props.dispatch(projectActions.getProblemType());
    }

    componentWillReceiveProps(nextProps) {
        let {groups} = this.props;
        let nextGroups = nextProps.groups;
        if (groups.project != nextGroups.project) {
            this.props.dispatch(projectActions.clearState());
            this.props.dispatch(projectActions.getDatasetMeta({id: nextGroups.project.datasets[0].id, name: nextGroups.project.datasets[0].name}))
        }
    }


    render() {
        const { groups  } = this.props;
        const { group, submitted } = this.state;

        const meta_options = [
            {id: 0, name: 'Sales'},
            {id: 1, name: 'Time'}
        ];

        const problem_options = [
            {id: 0, name: 'Forecast'},
            {id: 1, name: 'Prediction'}
        ];

        const DefineInputValidationSchema = Yup.object().shape({
            y_yariable: Yup.string()
                .required('Y yariable is required'),
            time_yariable: Yup.string()
                .required('Time yariable is required'),
            problem_type: Yup.string()
                .required('Problem type is required'),
        });

        const form = <Formik
            initialValues={{ y_yariable: '', time_yariable: '', problem_type: '' }}
            validationSchema={DefineInputValidationSchema}
            onSubmit={(values, { setSubmitting }) => {
                values.project = this.state.project_id;
                values.processed_file = groups.metas[0].dataset.id;
                this.props.dispatch(projectActions.createTraining(values, this.state.project_id));
                setSubmitting(false);
            }}
        >
            {({ isSubmitting }) => (
                <Form>
                    <div className="form-group form-container">
                        <label htmlFor="first_name">What do you want to predict?</label>
                        <Field component="select" className="form-control" name="y_yariable">
                            <option>Select option</option>
                            {
                                groups.metas && groups.metas.length > 0 && groups.metas[0].meta.map((obj) =>
                                    <option key={obj.id} value={obj.id}>{obj.column_name}</option>
                                )
                            }
                        </Field>
                        <ErrorMessage name="y_yariable" className="help-block" component="div" />
                    </div>

                    <div className="form-group form-container">
                        <label htmlFor="first_name">What is your problem type?</label>
                        <Field component="select" className="form-control" name="problem_type">
                            <option>Select option</option>
                            {
                                groups.problem_type  && groups.problem_type.map((obj) =>
                                    <option key={obj.id} value={obj.id}>{obj.name}</option>
                                )
                            }
                        </Field>
                        <ErrorMessage name="problem_type" className="help-block" component="div" />
                    </div>

                    <div className="form-group form-container">
                        <label htmlFor="first_name">What is your time yariable?</label>
                        <Field component="select" className="form-control" name="time_yariable">
                            <option>Select option</option>
                            {
                                groups.metas && groups.metas.length > 0 && groups.metas[0].meta.map((obj) =>
                                    <option key={obj.id} value={obj.id}>{obj.column_name}</option>
                                )
                            }
                        </Field>
                        <ErrorMessage name="time_yariable" className="help-block" component="div" />
                    </div>

                    <button type="submit" className="btn btn-primary" disabled={isSubmitting}>
                        Start training
                    </button>

                </Form>
            )}
        </Formik>;



        return (
            <React.Fragment>
            <div className="col-md-6 col-md-offset-3">
                <h2>Define Inputs</h2>
                {form}
            </div>
            </React.Fragment>
        );
    }
}

function mapStateToProps(state) {
    const { groups } = state;
    return {
        groups
    };
}

const connectedDefineInputPage = connect(mapStateToProps)(DefineInputPage);
export { connectedDefineInputPage as DefineInputPage };