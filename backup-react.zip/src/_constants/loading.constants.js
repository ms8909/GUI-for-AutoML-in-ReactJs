export const loadingConstants = {
    LOADING: 'LOADING',
};