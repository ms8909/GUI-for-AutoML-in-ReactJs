import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import './dashboard.css'
import Dropzone from 'react-dropzone'
import { projectActions } from '../_actions';
import classNames from 'classnames'
import TreeView from 'deni-react-treeview';
import Steps, { Step } from 'rc-steps';
import './steps/assets/index.less';
import './steps/assets/iconfont.less';
import { RecordMapper } from "../_components";
import ReactTable from "react-table";
import 'react-table/react-table.css'
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import withStyles from '@material-ui/core/styles/withStyles';
import Chip from '@material-ui/core/Chip';
import CloudUploadIcon from '@material-ui/icons/CloudUpload';
import DoneIcon from '@material-ui/icons/Done';
import CircularProgress from '@material-ui/core/CircularProgress';
import Button from '@material-ui/core/Button';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import ReactPaginate from 'react-paginate';


const styles = theme => ({
    root: {
        flexGrow: 1,
        backgroundColor: theme.palette.grey['100'],
        paddingBottom: 200,
        paddingTop: 50,
    },
    grid: {
        width: 1200,
        justifyContent: 'start',
        margin: `0 ${theme.spacing.unit * 2}px`,
        [theme.breakpoints.down('sm')]: {
            width: 'calc(100% - 20px)'
        }
    },
    loadingState: {
        opacity: 0.05
    },
    paper: {
        padding: theme.spacing.unit * 3,
        textAlign: 'left',
        color: theme.palette.text.secondary
    },
    statusItem: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingRight: 50
    },
    treeView: {
        width: '100%',
        border: 0,
        height: 150,
        backgroundColor: '#FFF',
        color: 'rgba(0, 0, 0, 0.87)',
        fontSize: '0.875rem',
        fontFamily: "Roboto"
    },
    mapper:{
        height: 200
    },
    delete: {
        color: 'red'
    },
    upload: {
        fontSize: '3.5rem',
        color: '#4caf50',
    },
    tabContainer:{
        marginTop: 30,
        overflowX: 'scroll'
    }
});

class DashboardPage extends React.Component {
    constructor(props){
        super(props);
        this.onDrop = this.onDrop.bind(this);
        this.onLinkChange = this.onLinkChange.bind(this);
        this.onSelectDataset = this.onSelectDataset.bind(this);
        this.state = {
            selected : -1,
            datasets: [{
                id: -1,
                text: 'Datasets',
                children: []
            }],
            tab: 0
        }
    }
    componentDidMount() {
        const { id } = this.props.match.params;
        this.setState({
            project_id: id,
        });
        this.props.dispatch(projectActions.getProject(id));
        this.props.dispatch(projectActions.getType());
        this.props.dispatch(projectActions.getRole());
        this.props.dispatch(projectActions.getImputation());
        this.props.dispatch(projectActions.getConnections(id));
    }

    handleDeleteUser(id) {
        return (e) => this.props.dispatch(userActions.delete(id));
    }

    onDrop(files){
       for(let file of files) {
           var data = new FormData();
           data.append('file_url', file);
           data.append('project', this.state.project_id);
           this.props.dispatch(projectActions.addDataset(data, this.state.project_id));
       }
    }

    onMetaChange(event, meta_id){
        const { name, value } = event.target;
        let data = new FormData();
        data.append(name, value);
        this.props.dispatch(projectActions.updateMeta(meta_id, data));
    }

    addConnections(nodes) {
        let {groups} = this.props;
        for (let node of nodes) {
            let exist = false;
            if(groups.connections!=undefined) {
                for (let connection of groups.connections) {
                    if (node.from_column == connection.from_column && node.to_column == connection.to_column) exist = true;
                }
            }
            if(!exist){
                node.project = this.state.project_id;
                this.props.dispatch(projectActions.addConnection(this.state.project_id, JSON.stringify(node)))
            }
        }
    }

    deleteConnection(nodes) {
        let {groups} = this.props;
        for (let connection of groups.connections) {
            let exist = false;
            for (let node of nodes) {
               if (node.from_column == connection.from_column && node.to_column == connection.to_column) exist = true;
            }
            if(!exist){
                this.props.dispatch(projectActions.deleteConnection(connection.id, this.state.project_id))
            }
        }
    }

    onLinkChange(value){
        let links = value.linkDataArray;
        let { groups } = this.props;
        let nodes = [];
        for(let link of links){
            let {from, fromPort, to, toPort} = link;
            let from_id;
            let to_id;
            for(let set of groups.metas) {
                if (set.dataset.name.indexOf(from)!=-1) {
                    for(let column of set.meta){
                        if(column.column_name==fromPort)from_id = column.id;
                    }
                }
                if (set.dataset.name.indexOf(to)!=-1) {
                    for(let column of set.meta){
                        if(column.column_name==toPort)to_id = column.id;
                    }
                }
            }

            nodes.push({from_column: from_id, to_column: to_id})
        }
        this.addConnections(nodes);
        this.deleteConnection(nodes);
    }

    onSelectDataset(e){
        if(this.state.selected != e.id)
                this.setState({
                    selected: e.id
                });
    }

    componentWillReceiveProps(nextProps) {
        let {groups} = this.props;
        let nextGroups = nextProps.groups;
        if (groups.project != nextGroups.project) {
            this.props.dispatch(projectActions.clearState());
            var sets = [];
            for (let set of nextGroups.project.datasets) {
                sets.push({
                    id: set.id,
                    text: set.name,
                    isLeaf: true
                })
                this.props.dispatch(projectActions.getDatasetMeta({id: set.id, name: set.name}))
                this.props.dispatch(projectActions.getDatasetData(set.id))
            }
            this.setState({
                datasets: [{
                    id: -1,
                    text: 'Datasets',
                    children: sets
                }]
            })
        }
    }

    deleteDataset(e, id){
        var r = confirm("Are you sure you want to delete dataset!");
        if (r == true) this.props.dispatch(projectActions.deleteDataset(id, this.state.project_id));
    }

    render() {
        const { groups, classes } = this.props;

        // const nodeData = [
        //     { key: "Sales",
        //         fields: [
        //             { name: "id" },
        //             { name: "sale" },
        //             { name: "time" }
        //         ],
        //         loc: "0 0" },
        //     { key: "Customers",
        //         fields: [
        //             { name: "id" },
        //             { name: "name" },
        //             { name: "address" },
        //             { name: "phone" }
        //         ],
        //         loc: "250 0" },
        // ];

        // const linkData = [
        //     { from: "Sales", fromPort: "id", to: "Customers", toPort: "id" },
        // ];

        const linkData = []

        // const data = [
        //     {id: '1', sale: '100',time: '10th Jan, 2018', color: 'red'},
        //     {id: '2', sale: '20',time: '11th Jan, 2018', color: 'yellow'},
        //     {id: '3', sale: '50',time: '12th Jan, 2018', color: 'blue'},
        //     {id: '4', sale: '150',time: '13th Jan, 2018', color: 'green'},
        //     {id: '5', sale: '75',time: '14th Jan, 2018', color: 'white'},
        // ];

        // const meta_data = [
        //     {id: 1, column_name: 'Sale', type: {id: 1}, role: {id: 0}, imputation: {id:2}, calculations:{mean: 0, mode: 0, median: 0, min: 0, max:0, count:0, missing:0}, graph:{date:[{x:10, y:4},{x:5, y:2}]}},
        //     {id: 1, column_name: 'Time', type: {id: 0}, role: {id: 0}, imputation: {id:1}, calculations:{mean: 0, mode: 0, median: 0, min: 0, max:0, count:0, missing:0}, graph:{date:[{x:5, y:6},{x:5, y:2}]}},
        //     {id: 1, column_name: 'Color', type: {id: 2}, role: {id: 0}, imputation: {id:0}, calculations:{mean: 0, mode: 0, median: 0, min: 0, max:0, count:0, missing:0}, graph:{date:[{x:15, y:8},{x:5, y:2}]}},
        // ];

        const types = [
            {id:0, name:'String'},
            {id:1, name:'Number'},
            {id:2, name:'Float'}
        ];

        const roles = [
            {id:0, name:'Feature'},
        ];

        const imputation = [
            {id:0, name:'Mean'},
            {id:1, name:'Mode'},
            {id:2, name:'Median'}
        ];



        const columns = [{
            Header: 'Id',
            accessor: 'id'
        },{
            Header: 'Sale',
            accessor: 'sale'
        },{
            Header: 'Time',
            accessor: 'time'
        },
        {
            Header: 'Color',
            accessor: 'color'
        }];


        const meta_table = <Table>
            <TableHead>
                <TableRow>
                    <TableCell>Column name</TableCell>
                    <TableCell>Type</TableCell>
                    <TableCell>Role</TableCell>
                    <TableCell>Imputation</TableCell>
                    <TableCell>&nbsp;</TableCell>
                </TableRow>
            </TableHead>
            <TableBody>
                {groups.metas && groups.metas.length > 0 && groups.metas[0].meta.map((row, index) => (
                    <TableRow key={index}>
                        <TableCell align="left">
                            <Typography variant="subtitle2" gutterBottom>
                                {row.column_name}
                            </Typography>
                        </TableCell>
                        <TableCell align="left">
                            <Select
                                value={row.type}
                                onChange={(e)=>this.onMetaChange(e, row.id)}
                                inputProps={{
                                    name: 'type',
                                }}
                            >
                                {groups.meta_type && groups.meta_type.map((obj) => (
                                    <MenuItem key={obj.id} value={obj.id}>{obj.name}</MenuItem>
                                ))}
                            </Select>
                        </TableCell>
                        <TableCell align="left">
                            <Select
                                value={row.type}
                                onChange={(e)=>this.onMetaChange(e, row.id)}
                                inputProps={{
                                    name: 'role',
                                }}
                            >
                                {groups.meta_type && groups.meta_role.map((obj) => (
                                    <MenuItem key={obj.id} value={obj.id}>{obj.name}</MenuItem>
                                ))}
                            </Select>
                        </TableCell>
                        <TableCell align="left">
                            <Select
                                value={row.type}
                                onChange={(e)=>this.onMetaChange(e, row.id)}
                                inputProps={{
                                    name: 'imputation',
                                }}
                            >
                                {groups.meta_type && groups.meta_role.map((obj) => (
                                    <MenuItem key={obj.id} value={obj.id}>{obj.name}</MenuItem>
                                ))}
                            </Select>
                        </TableCell>
                        <TableCell align="left">
                            <Grid container style={{display:'flex',flexWrap:'wrap'}}>
                                <Typography variant="body2" gutterBottom>Mean: {row.mean},&nbsp;</Typography>
                                <Typography variant="body2" gutterBottom>Stdev: {row.stdev},&nbsp;</Typography>
                                <Typography variant="body2" gutterBottom>Min: {row.min},&nbsp;</Typography>
                                <Typography variant="body2" gutterBottom>Max: {row.max},&nbsp;</Typography>
                                <Typography variant="body2" gutterBottom>Count: {row.count},&nbsp;</Typography>
                                <Typography variant="body2" gutterBottom>Missing: {row.missing}&nbsp;</Typography>
                            </Grid>
                        </TableCell>
                    </TableRow>
                ))}
            </TableBody>
        </Table>;




        const meta_columns = [{
            Header: 'Column nam',
            accessor: 'column_name'
        },{
            Header: 'Type',
            id: 'type',
            accessor: d => d,
            Cell: row => (
                <select className="form-control" name="type" value={row.value.type} onChange={(e)=>this.onMetaChange(e, row.value.id)}>
                    <option>Select meta type</option>
                    {
                        groups.meta_type && groups.meta_type.map((obj) => (
                            <option key={obj.id} value={obj.id}>{obj.name}</option>
                        ))
                    }
                </select>
            )
        },
            {
                Header: 'Role',
                id: 'role',
                accessor: d => d,
                Cell: row => (
                    <select className="form-control" name="role" value={row.value.role} onChange={(e)=>this.onMetaChange(e, row.value.id)}>
                        <option>Select meta role</option>
                        {
                            groups.meta_role && groups.meta_role.map((obj) => (
                                <option key={obj.id} value={obj.id}>{obj.name}</option>
                            ))
                        }
                    </select>
                )
            },
            {
                Header: 'Imputation',
                id: 'imputation',
                accessor: d => d,
                Cell: row => (
                    <select className="form-control" name="imputation" value={row.value.imputation} onChange={(e)=>this.onMetaChange(e, row.value.id)}>
                        <option>Select meta imputation</option>
                        {
                            groups.meta_imputation && groups.meta_imputation.map((obj) => (
                                <option key={obj.id} value={obj.id}>{obj.name}</option>
                            ))
                        }
                    </select>
                )
            },
            {
                Header: '',
                id: 'calculations',
                accessor: d => d,
                Cell: row => (
                    <div style={{display:'flex',flexWrap:'wrap'}}>
                        <Typography variant="body2" gutterBottom>Mean: {row.value.mean},&nbsp;</Typography>
                        <Typography variant="body2" gutterBottom>Stdev: {row.value.stdev},&nbsp;</Typography>
                        <Typography variant="body2" gutterBottom>Min: {row.value.min},&nbsp;</Typography>
                        <Typography variant="body2" gutterBottom>Max: {row.value.max},&nbsp;</Typography>
                        <Typography variant="body2" gutterBottom>Count: {row.value.count},&nbsp;</Typography>
                        <Typography variant="body2" gutterBottom>Missing: {row.value.missing}&nbsp;</Typography>
                    </div>
                )
            },
            {
                Header: 'Distribution',
                id: 'distribution',
                accessor: d => d.distribution_data,
                Cell: row => (
                    <div>
                        <p>Plot graph</p>
                        { row.value &&
                            <p>data: {JSON.stringify(row.value)}</p>
                        }
                    </div>
                )
            }
        ];

        const status = <Paper className={classes.paper}>
            <Typography variant="h6" gutterBottom>Status</Typography>
            <Grid container>
                <Grid item sm={3} className={classes.statusItem}>
                    <div>
                        <Typography variant="subtitle2" gutterBottom>
                            1. Uploading data
                        </Typography>
                        <Chip
                            label="100s"
                            color="primary"
                        />
                    </div>
                    <DoneIcon color="primary"/>
                </Grid>
                <Grid item sm={3} className={classes.statusItem}>
                    <div>
                        <Typography variant="subtitle2" gutterBottom>
                            2. Reading raw data
                        </Typography>
                        <Chip
                            label="20%"
                            color="secondary"
                        />
                    </div>
                    <CircularProgress color="secondary" />
                </Grid>
                <Grid item sm={3}>
                    <Typography variant="subtitle2" gutterBottom>
                        3. Exploratory data analysis
                    </Typography>
                    <Chip
                        label="0%"
                    />
                </Grid>
                <Grid item sm={3}>
                    <Typography variant="subtitle2" gutterBottom>
                        4. Displaying data
                    </Typography>
                    <Chip
                        label="0%"
                    />
                </Grid>
            </Grid>
        </Paper>;




        return (

            <div className={classes.root}>
                <Grid container justify="center">
                    <Grid spacing={24} alignItems="start" justify="center" container className={classes.grid}>
                        <Grid item xs={12}>
                            {status}
                        </Grid>

                        <Grid item xs={3}>
                            <Paper className={classes.paper}>
                                <Typography variant="h6" gutterBottom>Datasets</Typography>
                                <TreeView className={classes.treeView} items={ this.state.datasets } onSelectItem={this.onSelectDataset}/>
                            </Paper>
                            {
                                this.state.selected!=-1 &&
                                groups.project.datasets.map((obj) =>
                                    this.state.selected == obj.id &&
                                    <React.Fragment key={obj.id}>
                                        <br/>
                                        <Paper className={classes.paper}>
                                            <Typography variant="subtitle2" gutterBottom>Dataset name</Typography>
                                            <Typography variant="body2" gutterBottom>{obj.name}</Typography>
                                            <br/>
                                            <Typography variant="subtitle2" gutterBottom>No of rows</Typography>
                                            <Typography variant="body2" gutterBottom>{obj.rows}</Typography>
                                            <br/>
                                            <Button onClick={(e)=>{this.deleteDataset(e, obj.id)}} size="small" className={classes.delete}>
                                                Delete
                                            </Button>
                                         </Paper>
                                    </React.Fragment>
                                )
                            }
                            <br/>
                            <Paper className={classes.paper}>
                                <Dropzone onDrop={this.onDrop}>
                                    {({getRootProps, getInputProps, isDragActive}) => {
                                        return (
                                            <div
                                                {...getRootProps()}
                                                className={classNames('dropzone', {'dropzone--isActive': isDragActive})}
                                                style={{display: 'flex', textAlign: 'center', alignItems: 'center'}}>
                                                <input {...getInputProps()} />
                                                {
                                                    isDragActive ?

                                                        <Typography variant="subtitle2" gutterBottom>Drop datasets here...</Typography> :
                                                        <Typography variant="subtitle2" gutterBottom>
                                                            <CloudUploadIcon className={classes.upload}/>
                                                            <br/>
                                                            Try dropping some files here, or click to select files to upload.
                                                        </Typography>
                                                }
                                            </div>
                                        )
                                    }}
                                </Dropzone>
                            </Paper>

                        </Grid>

                        <Grid item xs={9}>
                            <Paper className={classes.paper}>
                                <Typography variant="h6" gutterBottom>Relationships</Typography>

                                {groups.tables && groups.linkData &&  groups.tables.length == groups.project.datasets.length &&
                                    <div className={classes.mapper}>
                                        <RecordMapper nodeData={groups.tables} linkData={groups.linkData} onChange={this.onLinkChange}/>
                                    </div>
                                }
                            </Paper>

                            <br/>

                            <Paper className={classes.paper}>
                                <Tabs
                                    value={this.state.tab}
                                    onChange={(e, value)=>{this.setState({tab: value})}}
                                    indicatorColor="primary"
                                    textColor="primary"
                                >
                                    <Tab label="View metadata" />
                                    <Tab label="View data" />
                                </Tabs>
                                {this.state.tab === 0 &&
                                <div className={classes.tabContainer}>
                                    {groups.metas && groups.metas.length > 0 &&
                                        meta_table
                                    }
                                </div>
                                }

                                {this.state.tab === 1 &&
                                <div className={classes.tabContainer}>
                                    {groups.dataset_data &&
                                    <div>
                                        <ReactPaginate
                                            previousLabel={'previous'}
                                            nextLabel={'next'}
                                            breakLabel={'...'}
                                            breakClassName={'break-me'}
                                            pageCount={20}
                                            marginPagesDisplayed={2}
                                            pageRangeDisplayed={5}
                                            onPageChange={()=>{console.log('page change')}}
                                            containerClassName={'pagination'}
                                            subContainerClassName={'pages pagination'}
                                            activeClassName={'active'}
                                        />
                                        <Table>
                                            <TableHead>
                                                <TableRow>
                                                    {groups.dataset_data_columns.map((obj, index) => (
                                                        <TableCell key={index}>{obj.Header}</TableCell>
                                                    ))}
                                                </TableRow>
                                            </TableHead>
                                            <TableBody>
                                                {groups.dataset_data.map((row, index) => (
                                                    <TableRow key={index}>
                                                        {groups.dataset_data_columns.map((obj, index1) => (
                                                            <TableCell key={index1} align="right">{row[obj.Header]}</TableCell>
                                                        ))}
                                                    </TableRow>
                                                ))}
                                            </TableBody>
                                        </Table>
                                    </div>

                                    }
                                </div>
                                }

                            </Paper>



                        </Grid>
                    </Grid>
                </Grid>
            </div>


        /*

            <div className="row">
                <div className="col-md-2 col-sm-3">
                    <div className="card-container treeview-container h-60">
                        <TreeView style={{'height': '40vh'}} items={ this.state.datasets } onSelectItem={this.onSelectDataset}/>
                        {
                            this.state.selected!=-1 &&
                            groups.project.datasets.map((obj) =>
                                this.state.selected == obj.id &&
                                <div key={obj.id} style={{'padding': '10px'}}>
                                    <span style={{fontWeight: 'bold'}}>Dataset name:</span> {obj.name}<br/>
                                    <span style={{fontWeight: 'bold'}}>No of rows:</span> {obj.rows}<br/>
                                    <a href={obj.file_url} target="_blank">View dataset</a><br/>
                                    <a onClick={(e)=>{this.deleteDataset(e, obj.id)}} style={{'color': 'red'}}>Delete dataset</a><br/>
                                </div>
                            )
                        }
                    </div>
                    <div className="card-container h-40">
                        <Dropzone onDrop={this.onDrop}>
                            {({getRootProps, getInputProps, isDragActive}) => {
                                return (
                                    <div
                                        {...getRootProps()}
                                        className={classNames('dropzone', {'dropzone--isActive': isDragActive})}
                                        style={{display: 'flex', textAlign: 'center', alignItems: 'center'}}>
                                        <input {...getInputProps()} />
                                        {
                                            isDragActive ?

                                                <p>Drop datasets here...</p> :
                                                <p><i style={{fontSize: '40px', padding: '10px'}} className="fas fa-cloud-upload-alt"></i><br/>Try dropping some files here, or click to select files to upload.</p>
                                        }
                                    </div>
                                )
                            }}
                        </Dropzone>
                    </div>
                </div>
                <div className="col-md-10 col-sm-9">

                    <div className="row">
                        <div className="col-md-8 col-sm-8">
                            <div className="card-container h-40">
                                {groups.tables && groups.linkData &&  groups.tables.length == groups.project.datasets.length &&
                                    <RecordMapper nodeData={groups.tables} linkData={groups.linkData} onChange={this.onLinkChange}/>
                                }
                            </div>
                        </div>
                        <div className="col-md-4 col-sm-4">
                            <div className="card-container mh-40" style={{padding: '10px'}}>
                                <Steps direction="vertical">
                                    <Step title="Uploading data" />
                                    <Step title="Reading raw data" />
                                    <Step title="Exploratory data analysis" />
                                    <Step title="Displaying data" />
                                </Steps>
                                {
                                    groups.metas && groups.metas.length > 0 && groups.project.status == 'Pending' &&
                                    <div style={{width: '100%', textAlign: 'center'}}>
                                        <Link to={"/input/"+this.state.project_id} className="btn btn-primary">Proceed to training</Link>
                                    </div>
                                }
                            </div>
                        </div>
                    </div>

                    <div className="row">
                        <div className="col-sm-12">
                            <div className="card-container h-60">

                                <div className="row">
                                    <div className="col-md-12">
                                        <div className="card">
                                            <ul className="nav nav-tabs" role="tablist">
                                                <li role="presentation" className="active"><a data-target="#home"
                                                                                              aria-controls="home"
                                                                                              role="tab"
                                                                                              data-toggle="tab">Meta data</a>
                                                </li>
                                                <li role="presentation"><a data-target="#profile" aria-controls="profile"
                                                                           role="tab" data-toggle="tab">Tabular view</a></li>

                                            </ul>
                                            <div className="tab-content">
                                                <div role="tabpanel" className="tab-pane active" id="home">
                                                    {groups.metas && groups.metas.length > 0 &&
                                                        <ReactTable
                                                            data={groups.metas[0].meta}
                                                            columns={meta_columns}
                                                        />
                                                    }
                                                </div>
                                                <div role="tabpanel" className="tab-pane" id="profile">
                                                    {groups.dataset_data &&
                                                        <ReactTable
                                                            data={groups.dataset_data}
                                                            columns={groups.dataset_data_columns}
                                                        />
                                                    }
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
            */
        );
    }
}

function mapStateToProps(state) {
    const { groups, authentication } = state;
    const { user } = authentication;
    return {
        user,
        groups
    };
}

const connectedDashboardPage = withStyles(styles)(connect(mapStateToProps)(DashboardPage));
export { connectedDashboardPage as DashboardPage };